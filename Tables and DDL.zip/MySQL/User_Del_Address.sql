INSERT INTO delivery_address (country, city, street, zipcode, user_id) VALUES
('Philippines','Manila','España Blvd Sampaloc',1008,1),
('Philippines','Cavite','Bancal Carmona',4116,2),
('Philippines','Makati','J.P. Rizal Ext',1215,3),
('Philippines','Pasig','Pearl Dr Ortigas Center',1605,4);