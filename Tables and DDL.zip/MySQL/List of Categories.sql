INSERT INTO category (category_name) VALUES
('Bakery'), 
('Beverages'), 
('Canned/Jarred Goods'),
('Cleaners'), 
('Dairy'), 
('Dry/Baking Goods'), 
('Frozen Foods'),
('Meat'),
('Others'),
('Paper Goods'), 
('Personal Care'), 
('Produce');