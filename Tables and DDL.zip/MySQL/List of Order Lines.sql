INSERT INTO order_lines (total_products, product_price, product_id, user_id) VALUES
(1,749.75,55,2),
(2,229.75,100,2),
(2,109.75,2,2),
(1,373.75,298,2),
(1,299.75,304,2),
(1,124.25,262,2),
(5,199.75,200,2),
(1,359.75,205,2);