INSERT INTO category (category_name, image_url) VALUES
('Bakery','https://lewisfresh.com/wp-content/uploads/2018/05/lewis-fresh-market-bakery-department.jpg'),
('Beverages','https://i.ytimg.com/vi/cBUbbyju65o/hqdefault.jpg'),
('Canned/Jarred Goods','https://cdn-a.william-reed.com/var/wrbm_gb_food_pharma/storage/images/1/7/7/0/2430771-1-eng-GB/Canned-foods-industry-in-decline.jpg'),
('Cleaners','https://runcitoncall.com/image/runcitoncall/image/data/category/house-hold.jpg'),
('Dairy','https://media.gettyimages.com/photos/dairy-products-at-the-supermarket-picture-id521871746'),
('Dry/Baking Goods','https://food.fnr.sndimg.com/content/dam/images/food/fullset/2015/5/27/0/FN_baking-ingredient-guide-flours-01-stock_s4x3.jpg.rend.hgtvcom.406.305.suffix/1432735992674.jpeg'),
('Frozen Foods','https://cdn.shopify.com/s/files/1/0264/3420/7802/collections/2F1E7F96-7BE2-4ED4-BF30-C1D3FB78D0B8.jpg?v=1593317569'),
('Meat','https://www.jbtc.com/foodtech/wp-content/uploads/sites/2/2021/08/Beef-Poultry-Fish.jpeg'),
('Others','https://i0.wp.com/thepostpartumparty.com/wp-content/uploads/2020/01/What-to-stock-up-on-before-baby-1.jpg?fit=1024%2C556&ssl=1'),
('Paper Goods','https://www.gannett-cdn.com/presto/2020/04/16/USAT/06cb72c5-ccfc-4fab-9bcc-7c74d9a0f46a-toilet-paper.jpg?width=660&height=372&fit=crop&format=pjpg&auto=webp'),
('Personal Care','https://foodro.in/media/category//category-16020855204011.jpeg'),
('Produce','https://www.zdnet.com/a/img/resize/83b666abbcf7e2e9ab7886c43880a4943441b05c/2021/04/26/c6f4bf8a-1392-4909-81e9-4a6b4067a958/coles-supermarket-fresh-produce.jpg?fit=bounds&auto=webp');